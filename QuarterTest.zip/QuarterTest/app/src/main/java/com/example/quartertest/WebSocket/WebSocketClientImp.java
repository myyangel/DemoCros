package com.example.quartertest.WebSocket;

import android.util.Log;

import com.app.mg.connectionlibraryandroid.Entities.MessageBody;
import com.app.mg.connectionlibraryandroid.Implementations.MessageMethods;
import com.example.quartertest.Interfaces.WebSocketReceiver;
import com.google.gson.internal.LinkedTreeMap;

import org.java_websocket.WebSocket;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

public class WebSocketClientImp extends WebSocketClient {

    private WebSocketReceiver receiverMethod;

    public WebSocketClientImp(URI serverUri) {
        super(serverUri);
    }

    public WebSocketClientImp(URI serverUri, WebSocketReceiver receiver) {
        super(serverUri);
        this.receiverMethod = receiver;
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        Log.i("CLIENT OPEN","Arrive Open");
    }

    @Override
    public void onMessage(String message) {
        receiverMethod.onWebSocketMessage(message);
        Log.i("CLIENT MESSAGE:","Arrive Message");
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        receiverMethod.onWebSocketClose(code,reason,remote);
        Log.i("CLIENT CLOSE:","Arrive Close");
    }

    @Override
    public void onError(Exception ex) {
        Log.i("CLIENT ERROR","Arrive error: "+ex.getMessage());
    }

}