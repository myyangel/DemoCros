package com.example.quartertest.Activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.mg.connectionlibraryandroid.Implementations.ConnectMethods;
import com.app.mg.connectionlibraryandroid.Implementations.MessageMethods;
import com.example.quartertest.Entities.TestMessage;
import com.example.quartertest.Interfaces.WebSocketReceiver;
import com.example.quartertest.R;
import com.example.quartertest.Utilities.ImageUtility;
import com.example.quartertest.WebSocket.WebSocketClientImp;
import com.google.gson.Gson;

import org.java_websocket.WebSocket;

import java.io.FileNotFoundException;
import java.io.InputStream;

public class ClientActivity extends AppCompatActivity implements WebSocketReceiver {

    private String serverIpAddress = "";
    private String myIpAddress = "";
    private final String  SERVER_PORT = "8080";

    WebSocketClientImp wsClient;

    private ImageView imageView;
    private Button btnSubmitImage, btnSendImage, btnCloseSession;
    private TextView myIpTextView;
    private ConnectMethods connectMethods = new ConnectMethods();
    private Handler handler;
    MessageMethods<TestMessage ,WebSocketClientImp, WebSocket> messageMethods = new MessageMethods<>();
    private Gson gson = new Gson();

    private final int MAX_WIDTH_IMAGE = 1400;
    private final int MAX_HEIGHT_IMAGE = 1600;

    private int min_distance = 400;
    private float downX, downY, upX, upY;

    private boolean send_image = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);

        serverIpAddress = getIntent().getStringExtra("ipServer");
        myIpAddress = connectMethods.FindMyIpAddress(this);
        btnSendImage = findViewById(R.id.send_data);
        btnSubmitImage = findViewById(R.id.submit_image);
        btnCloseSession = findViewById(R.id.disconnect_server);
        imageView = findViewById(R.id.imageViewClient);
        myIpTextView = findViewById(R.id.text_ip_client);
        myIpTextView.setText(myIpAddress);

        imageView.setOnTouchListener(onTouchListener());

        btnSubmitImage.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");

            startActivityForResult(Intent.createChooser(intent,"Pick Image"), 1);
        });
        btnSendImage.setOnClickListener(view -> {
            try{
                sendMessageToServer();
            } catch (Exception e){
                Toast.makeText(getApplicationContext(),"Error en el Servidor",Toast.LENGTH_SHORT).show();
            }
        });

        btnCloseSession.setOnClickListener(view -> {
            wsClient.close();
            finish();
        });
        handler = new Handler();
        connectWebSocket();
    }

    private void sendMessageToServer() {
        String type = imageView.getDrawable().getClass().getSimpleName();
        if (imageView.getDrawable() != null && type.equals("BitmapDrawable") && send_image && wsClient.isOpen()){
            send_image = false;
            btnSendImage.setEnabled(false);
            Toast.makeText(getApplicationContext(),"Enviando....",Toast.LENGTH_SHORT).show();
            String base64Image = checkImageResolution(imageView);
            createAndSendMessage(base64Image);
            Toast.makeText(getApplicationContext(),"Imagen Enviada",Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(),"No hay imagen para enviar",Toast.LENGTH_SHORT).show();
        }
    }

    public void createAndSendMessage(String parseImage){
        TestMessage testMessage = new TestMessage()
                .setSender(myIpAddress)
                .setBase64Image(parseImage);
        String test = gson.toJson(testMessage);
        wsClient.send(test);
    }

    private String checkImageResolution(ImageView imageView){
        BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
        Bitmap bitmap = drawable.getBitmap();
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        boolean isPortrait = width < height;
        String base64Image;
        if(width <= MAX_WIDTH_IMAGE && height <= MAX_HEIGHT_IMAGE ) {
            base64Image = ImageUtility.convertToBase64(imageView);
        } else {
            base64Image = ImageUtility.resizeImageAndConvertToBase64(imageView, isPortrait);
        }
        return base64Image;
    }

    private void connectWebSocket() {
        wsClient = new WebSocketClientImp(connectMethods.GetUriServer(serverIpAddress,SERVER_PORT), this);
        wsClient.connect();
        Toast.makeText(getApplicationContext(),"Cliente Conectado",Toast.LENGTH_SHORT).show();
    }

    @SuppressLint("ClickableViewAccessibility")
    private OnTouchListener onTouchListener() {
        return (view, motionEvent) -> {

            switch (motionEvent.getAction() & MotionEvent.ACTION_MASK){
                case MotionEvent.ACTION_DOWN:
                    downX = motionEvent.getX();
                    downY = motionEvent.getY();
                    break;
                case MotionEvent.ACTION_UP:
                    upX = motionEvent.getX();
                    upY = motionEvent.getY();

                    float deltaX = downX - upX;
                    float deltaY = downY - upY;

                    //HORIZONTAL SCROLL
                    if(Math.abs(deltaX) > Math.abs(deltaY))
                    {
                        if(Math.abs(deltaX) > min_distance){
                            // left or right
                            if(deltaX < 0)
                            {
                                //Toast.makeText(ClientActivity.this,"right", Toast.LENGTH_SHORT).show();
                                sendMessageToServer();
                                return true;
                            }
                            if(deltaX > 0) {
                                //Toast.makeText(ClientActivity.this,"left", Toast.LENGTH_SHORT).show();
                                sendMessageToServer();
                                return true;
                            }
                        }
                        else {
                            //not long enough swipe...
                            return false;
                        }
                    }
                    //VERTICAL SCROLL
                    else
                    {
                        if(Math.abs(deltaY) > min_distance){
                            // top or down
                            if(deltaY < 0)
                            {
                                //Toast.makeText(ClientActivity.this,"down", Toast.LENGTH_SHORT).show();
                                return true;
                            }
                            if(deltaY > 0)
                            {
                                //Toast.makeText(ClientActivity.this,"top", Toast.LENGTH_SHORT).show();
                                sendMessageToServer();
                                return true;
                            }
                        }
                        else {
                            //not long enough swipe...
                            return false;
                        }
                    }
                    break;
                case MotionEvent.ACTION_MOVE:

                    break;
            }
            return true;
        };
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && requestCode == 1) {
            try{
                InputStream inputStream = getContentResolver().openInputStream(data.getData());

                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

                imageView.setImageBitmap(bitmap);
            } catch (FileNotFoundException ex){

            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (wsClient != null){
            wsClient.close();
        }
    }


    @Override
    public void onWebSocketMessage(String message) {
        TestMessage testMessage = gson.fromJson(message, TestMessage.class);
        if(!testMessage.getSender().equals(myIpAddress)){
            Bitmap bitmap = ImageUtility.convertToBitmap(testMessage.getBase64Image());
            handler.post((Runnable) () -> {
                imageView.setImageBitmap(bitmap);
                btnSendImage.setEnabled(true);
            });
        }
        handler.post((Runnable) () -> {
            btnSendImage.setEnabled(true);
        });
        send_image = true;
    }

    @Override
    public void onWebSocketClose(int code, String reason, boolean remote) {
        if(code == 1001 && remote){
            handler.post((Runnable) () -> Toast.makeText(this, "SERVER WAS CLOSE", Toast.LENGTH_LONG).show());
            finish();
        }
    }
}
